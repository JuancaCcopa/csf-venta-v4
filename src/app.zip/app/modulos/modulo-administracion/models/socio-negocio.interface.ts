export interface ISocioNegocio {
    cardCode: string;
    cardName: string;
    federalTaxID: string;
    mailAddress: string;
}