export interface ITipoDocumento {
  idAprobacionDocumento: number;
  desAprobacionDocumento: string;
  regCreate: string;
  regUpdate: string;
  regCreateIdUsuario: number;
  regUpdateIdUsuario: number;
  isAprobacionDocumento: boolean;
}
