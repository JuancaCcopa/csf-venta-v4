export interface interfaceUsuario {
    // apellidoMaterno: string;
    // apellidoPaterno: string;
    codCentroCosto: string;
    desCentroCosto: string;
    // empleado: string;
    idPersona: number;
    idUsuario: number;
    nombresApellidos: string;
}
