export class ConstantsTablasIDB {
    // Tablas Maestras Modulo I
    public static _TABLA_ESTACION_TRABAJO = 'mstEstacionTrabajo';
}