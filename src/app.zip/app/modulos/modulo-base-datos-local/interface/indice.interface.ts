export interface IIndice {
    tabla: string;
    nombreIndice: string;
    campoIndice: string;
    unico: boolean;
}