import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dashboard-gerencial',
  templateUrl: './dashboard-gerencial.component.html',
  styleUrls: ['./dashboard-gerencial.component.css']
})
export class DashboardGerencialComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
