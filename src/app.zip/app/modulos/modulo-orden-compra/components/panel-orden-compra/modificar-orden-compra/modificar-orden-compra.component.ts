import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-modificar-orden-compra',
  templateUrl: './modificar-orden-compra.component.html',
  styleUrls: ['./modificar-orden-compra.component.css']
})
export class ModificarOrdenCompraComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
