export interface IGenerico {
    code: string
    name: string
}