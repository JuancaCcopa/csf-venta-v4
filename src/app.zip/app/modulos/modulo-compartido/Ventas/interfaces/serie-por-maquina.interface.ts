export interface ISeriePorMaquina {
    id: number;
    nombremaquina: string;
    seriefactura: string;
    serieboleta: string;
    serienotacredito: string;
    serienotadebito: string;
    serieguia: string;
    codcentro: string;
    codalmacen: string;
    serienotacreditofactura: string;
    serienotadebitofactura: string;
}