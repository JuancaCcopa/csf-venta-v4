export interface IWarehouses {
    warehouseCode: string
    warehouseName: string
}