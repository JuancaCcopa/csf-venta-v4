export interface IAtencion {
    nombrepaciente: string;
    atencion: string;
    estadopaciente: string;
    finicio: string;
    codpaciente: string;
}