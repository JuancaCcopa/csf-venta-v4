export interface IMedico {
    codmedico: string;
    nombres: string;
    ruc: string;
    direccion: string;
    telefono: string;
}