export interface ICentro {
    codcentro: string;
    nombre: string;
    codcuenta: string;
    codresponsable: string;
}