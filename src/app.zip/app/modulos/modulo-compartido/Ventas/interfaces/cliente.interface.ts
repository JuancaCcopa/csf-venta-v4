export interface ICliente {
    cardCode: string;
    cardName: string;
    mailAddress: string;
    phone1: string;
    federalTaxID: string;
    u_SYP_BPAP: string;
    u_SYP_BPAM: string;
    u_SYP_BPNO: string;
    u_SYP_BPN2: string;
    u_SYP_BPTP: string;
    u_SYP_BPTD: string;
}