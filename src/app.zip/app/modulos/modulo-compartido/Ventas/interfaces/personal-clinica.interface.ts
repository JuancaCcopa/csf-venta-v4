export interface IPersonalClinica {
    codpersonal: string;
    apellido: string;
    nombre: string;
    direccion: string;
    telefonocasa: string;
    nombreempresa: string;
}