export interface IServicio {
    code: string;
    name: string;
    u_SYP_Concepto: string;
    u_SYP_Cuenta: string;
    u_SYP_Origen: string;
}