export interface IRequerimientoItemBus {
    IdRequerimiento: number;
    FecRequerimiento: Date;
    nombreCompleto: string;
    desCentroCosto: string;
    obsConformidadSAP: string;
    desRequerimientoEstado: string;
}