export interface IGrupoArticulo {
    number: number;
    groupName: string;
}