export interface IMensajeResultadoApi {
    idRegistro: number;
    nombreEstacion: string;
    nombreAplicacion: string;
    resultadoCodigo: number;
    resultadoDescripcion: string;
    nombreMetodo: string;
  }  