export class LoginModel
{
    usuario?: string;
    clave?: string;

    constructor()
    {
        this.usuario = '';
        this.clave = '';
    }
}