import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-page-inicial',
  templateUrl: './page-inicial.component.html',
  styleUrls: ['./page-inicial.component.css']
})
export class PageInicialComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
