export interface InterfaceDispositivo {
    nombreDispositivo: string;
    esMovil: boolean;
    esTablet: boolean;
    esDesktop: boolean;
  }
  